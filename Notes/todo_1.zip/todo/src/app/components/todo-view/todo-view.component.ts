import { Component, Input, OnInit } from '@angular/core';
import { TodoModule } from 'src/app/model/todo/todo.module';
import { TodoService } from 'src/app/service/todo.service';

@Component({
  selector: 'app-todo-view',
  templateUrl: './todo-view.component.html',
  styleUrls: ['./todo-view.component.css']
})
export class TodoViewComponent implements OnInit {
  todos:Array<TodoModule> = [];
  @Input()
  newTodo:TodoModule = new TodoModule();
  constructor(private todoService:TodoService) {

    console.log("data from Parent",this.newTodo.title);
    
   }

  ngOnInit(): void {
    this.todoService.getTodo()
    .subscribe(data =>{
      this.todos = [...data,this.newTodo];
    })
  }

}
