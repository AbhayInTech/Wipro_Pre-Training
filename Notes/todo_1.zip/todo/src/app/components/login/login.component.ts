import { Component, OnInit} from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { UsersService } from 'src/app/service/users.service';
import { User } from '../../model/user/user.module';
// import { AuthService } from '../../services/auth.service';
import { RouterService } from '../../service/router.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User = new User();
  constructor(private routerService : RouterService,
              private userService : UsersService) { }

  ngOnInit(): void {
  }

  loginForm = new FormGroup(
    {
      username: new FormControl('',[Validators.required]),
      password: new FormControl('',[Validators.required,Validators.minLength(6)])
    }
  )
  async login(){
    console.log("Form Login",);
    this.user.username = this.loginForm.value.username;
    this.user.password = this.loginForm.value.password;
    let validData:boolean = false;
    await this.userService.getUsers()
    .subscribe(data => {
      data.forEach(mydata => {
        if(mydata.username === this.user.username && mydata.password === this.user.password){
          // console.log("inside treu");
          
          // validData = true;
          this.userService.storeName(this.user.username);
          this.routerService.toDashboard(this.loginForm.value.username);
        }

    })})
   
    

    // this.authService.validateUser(this.user).subscribe(data =>{
    //   this.authService.setToken(data['token']);
       
    // });
    
    
  }
  getUserName(){
    return this.loginForm.get('username');
  }
  getPassword(){
    return this.loginForm.get('password');
  }
  getUserNameErrorMsg(){
    if(this.getUserName()?.invalid && (this.getUserName()?.dirty || this.getUserName()?.touched)){
      return "User Name should not be blank"
    }else{
      return "";
    }
  }
  getPasswordErrorMsg(){
    if(this.getPassword()?.invalid &&(this.getPassword()?.dirty || this.getPassword()?.touched)){
      if(this.getPassword()?.hasError('required')){
        return "Password can not be blank"
      }
      else if(this.getPassword()?.hasError('minlength')){
        return "Password can not be less the 6 char"
      }
      else{
        return ""
      }
    }else{
      return ""
    }
  }

}
