import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';
import { User } from '../model/user/user.module';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private httpClient:HttpClient) { }

   getUsers():Observable<Array<User>>{
    return this.httpClient.get<Array<User>>('http://localhost:3000/users')
  }
  storeName(name:string){
    localStorage.setItem("userName",name);
  }
  getName():string|null{
    return localStorage.getItem('userName');
  }
  
}
