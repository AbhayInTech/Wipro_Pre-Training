import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class TodoModule {
  id:number = 0;
  title:String = "";
  text:String = "";
 }
