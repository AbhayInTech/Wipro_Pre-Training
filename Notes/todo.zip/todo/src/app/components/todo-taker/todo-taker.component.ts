import { Component, OnInit } from '@angular/core';
import { TodoModule } from 'src/app/model/todo/todo.module';
import { TodoService } from 'src/app/service/todo.service';

@Component({
  selector: 'app-todo-taker',
  templateUrl: './todo-taker.component.html',
  styleUrls: ['./todo-taker.component.css']
})
export class TodoTakerComponent implements OnInit {
  todo:TodoModule = new TodoModule();
  constructor(private todoService:TodoService) { }

  ngOnInit(): void {
  }
  getData(){
    console.log("Hello Todo"+this.todo.title);
    this.todoService.addTodo(this.todo)
    .subscribe(data => {
      this.todo = new TodoModule();
    })
    
  }

}
