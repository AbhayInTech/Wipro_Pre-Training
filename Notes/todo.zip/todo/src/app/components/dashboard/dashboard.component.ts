import { Component, OnInit, ViewChild } from '@angular/core';
import { TodoModule } from 'src/app/model/todo/todo.module';
import { TodoTakerComponent } from '../todo-taker/todo-taker.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild(TodoTakerComponent) todoTaker:any;
  todo:TodoModule = new TodoModule();
  username:String  = "";
  constructor(private router : ActivatedRoute) {
    this.router.queryParams.subscribe(params => {
      this.username = params['username'];
      
    })
    
   }

  ngOnInit(): void {
  }
  ngAfterViewInit() {
    this.todo = this.todoTaker.todo;
    console.log("From after view Init", this.todoTaker.todo);

  }

}
