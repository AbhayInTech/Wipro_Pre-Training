import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { TodoModule } from '../model/todo/todo.module';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class TodoService {

  constructor(private httpClient : HttpClient) { }
  addTodo(todo:TodoModule):Observable<TodoModule>{
    return this.httpClient.post<TodoModule>('http://localhost:3000/todos',todo)
  }
  getTodo():Observable<Array<TodoModule>>{
    return this.httpClient.get<Array<TodoModule>>('http://localhost:3000/todos')
  }
}
