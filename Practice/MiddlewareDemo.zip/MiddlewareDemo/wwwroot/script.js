console.log("Static JS loaded");
